from django.apps import AppConfig


class SparkappConfig(AppConfig):
    name = 'sparkapp'
